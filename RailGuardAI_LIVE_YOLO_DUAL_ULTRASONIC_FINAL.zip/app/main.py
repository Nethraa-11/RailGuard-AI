import os, sqlite3, hashlib, secrets, json, base64, io
from datetime import datetime, timezone
from pathlib import Path
from PIL import Image
from typing import Optional

from fastapi import FastAPI, Request, Form, WebSocket, WebSocketDisconnect, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

try:
    import ollama
except ImportError:
    ollama = None

try:
    import httpx
except ImportError:
    httpx = None

try:
    from ultralytics import YOLO
except ImportError:
    YOLO = None

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "data"
MEDIA = DATA / "sd_card"
MEDIA.mkdir(parents=True, exist_ok=True)
DB = DATA / "railguard.db"
YOLO_MODEL = os.getenv("YOLO_MODEL", str(BASE / "models" / "best.pt"))
OBJECT_YOLO_MODEL = os.getenv("OBJECT_YOLO_MODEL", str(BASE / "models" / "yolov8n.pt"))
ESP32_COMMAND_URL = os.getenv("ESP32_COMMAND_URL", "").strip()
ESP32_CAMERA_URL = os.getenv("ESP32_CAMERA_URL", "").strip()
DEVICE_KEY = os.getenv("DEVICE_KEY", "railguard-device-01")

app = FastAPI(title="RailGuard AI")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")
app.mount("/media", StaticFiles(directory=str(MEDIA)), name="media")

TOKENS = {}
clients = set()
_yolo_model = None
_object_yolo_model = None

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def hp(p): return hashlib.sha256(p.encode()).hexdigest()

def now(): return datetime.now(timezone.utc).isoformat()

def auth(request: Request):
    token = request.headers.get("Authorization", "").replace("Bearer ", "")
    return TOKENS.get(token)

def severity_from_detection(area_ratio: float, confidence: float) -> str:
    score = min(100, (area_ratio * 100 * 0.7) + (confidence * 100 * 0.3))
    if score >= 60: return "HIGH"
    if score >= 30: return "MEDIUM"
    return "LOW"

def get_yolo_model():
    global _yolo_model
    if YOLO is None:
        raise RuntimeError("Ultralytics is not installed. Run pip install -r requirements.txt.")
    model_path = Path(YOLO_MODEL)
    if not model_path.exists():
        raise FileNotFoundError(f"Crack model not found: {model_path}. Put your trained best.pt in models/ or set YOLO_MODEL.")
    if _yolo_model is None:
        _yolo_model = YOLO(str(model_path))
    return _yolo_model

def get_object_yolo_model():
    """Load a general-purpose pretrained YOLO model for common objects."""
    global _object_yolo_model
    if YOLO is None:
        raise RuntimeError("Ultralytics is not installed. Run pip install -r requirements.txt.")
    model_path = Path(OBJECT_YOLO_MODEL)
    if _object_yolo_model is None:
        if model_path.exists():
            _object_yolo_model = YOLO(str(model_path))
        else:
            # Ultralytics downloads the pretrained model on first use.
            # Copy/save it into models/ so subsequent starts use the local file.
            _object_yolo_model = YOLO("yolov8n.pt")
            try:
                model_path.parent.mkdir(parents=True, exist_ok=True)
                if Path("yolov8n.pt").exists() and not model_path.exists():
                    Path("yolov8n.pt").replace(model_path)
            except Exception:
                pass
    return _object_yolo_model

def _extract_detections(result, image_shape):
    names = result.names or {}
    h, w = image_shape[:2]
    detections = []
    for box in result.boxes:
        conf = float(box.conf[0]); cls = int(box.cls[0]); xyxy = [float(x) for x in box.xyxy[0].tolist()]
        area = max(0, xyxy[2]-xyxy[0]) * max(0, xyxy[3]-xyxy[1])
        detections.append({"label": str(names.get(cls, cls)), "confidence": round(conf * 100, 2),
                           "box": xyxy, "area_ratio": area / max(1, w*h)})
    return detections

def yolo_detect_bytes(raw: bytes, save_annotated: bool = True):
    """Run RailGuard crack model and a general-object YOLO model on the same frame."""
    crack_model = get_yolo_model()
    object_model = get_object_yolo_model()
    image = Image.open(io.BytesIO(raw)).convert("RGB")
    arr = __import__("numpy").array(image)
    crack_results = crack_model.predict(source=arr, conf=0.10, verbose=False)
    object_results = object_model.predict(source=arr, conf=0.35, verbose=False)
    crack_result = crack_results[0]
    object_result = object_results[0]

    crack_detections = _extract_detections(crack_result, arr.shape)
    object_detections = _extract_detections(object_result, arr.shape)
    best = None
    for d in crack_detections:
        candidate = {"label": d["label"], "confidence": d["confidence"] / 100,
                     "ratio": d["area_ratio"], "box": d["box"]}
        if best is None or candidate["confidence"] > best["confidence"]:
            best = candidate

    # Draw both model outputs on one image. Crack model is drawn first, then
    # general objects, so the operator can see both detection families.
    annotated = crack_result.plot()
    annotated = object_result.plot(img=annotated, labels=True, boxes=True, conf=True)
    from PIL import Image as PILImage
    annotated_rgb = annotated[:, :, ::-1]
    out = io.BytesIO(); PILImage.fromarray(annotated_rgb).save(out, format="JPEG", quality=88)
    return best, out.getvalue(), object_detections

def detection_payload(best, object_detections, source):
    if best:
        conf = best["confidence"] * 100
        result_label = best["label"].upper()
        sev = severity_from_detection(best["ratio"], best["confidence"])
        notes = f"Railway YOLO {source.lower()} detection. Bounding-box area ratio: {best['ratio']:.4f}. Severity is a prototype rule based on detected area and confidence."
    else:
        conf = 0; result_label = "NO CRACK"; sev = "LOW"
        notes = f"Railway YOLO {source.lower()} scan found no crack in this frame."
    return result_label, round(conf,2), sev, notes, object_detections

def save_inspection(robot_id: str, annotated_bytes: bytes, original_ext: str = ".jpg", source: str = "LIVE"):
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    name = f"{source.lower()}_detection_{stamp}.jpg"
    dest = MEDIA / name
    dest.write_bytes(annotated_bytes)
    return name, f"/media/{name}"

def record_yolo_result(robot_id: str, best, image_url: str, source: str):
    if best:
        conf = best["confidence"] * 100
        result_label = best["label"].upper()
        sev = severity_from_detection(best["ratio"], best["confidence"])
        notes = f"YOLOv8 {source.lower()} detection. Bounding-box area ratio: {best['ratio']:.4f}. Severity is a prototype rule based on detected area and confidence."
    else:
        conf = 0
        result_label = "NO CRACK"
        sev = "LOW"
        notes = f"YOLOv8 {source.lower()} scan found no crack in this frame."
    c = db()
    c.execute("INSERT INTO inspections(robot_id,timestamp,image_url,result,confidence,severity,notes) VALUES(?,?,?,?,?,?,?)",
              (robot_id, now(), image_url, result_label, round(conf,2), sev, notes))
    if best and sev == "HIGH":
        c.execute("INSERT INTO alerts(robot_id,timestamp,severity,type,message) VALUES(?,?,?,?,?)",
                  (robot_id, now(), "HIGH", "CRACK_DETECTED", f"High-severity crack detected with {conf:.1f}% confidence."))
    c.commit(); c.close()
    return result_label, round(conf,2), sev, notes

def init():
    c = db()
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE NOT NULL,
        mobile TEXT, password_hash TEXT NOT NULL, role TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS robots(
        id TEXT PRIMARY KEY, name TEXT, station TEXT, zone TEXT,
        status TEXT DEFAULT 'OFFLINE', last_seen TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS telemetry(
        id INTEGER PRIMARY KEY AUTOINCREMENT, robot_id TEXT, timestamp TEXT,
        battery_voltage REAL, battery_percent REAL, latitude REAL, longitude REAL,
        speed REAL, front_distance REAL, rear_distance REAL, ultrasonic_distance REAL,
        ir_left INTEGER, ir_right INTEGER, emergency_stop INTEGER, train_approaching INTEGER,
        camera_status TEXT, connection_status TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS alerts(
        id INTEGER PRIMARY KEY AUTOINCREMENT, robot_id TEXT, timestamp TEXT,
        severity TEXT, type TEXT, message TEXT, acknowledged INTEGER DEFAULT 0)""")
    c.execute("""CREATE TABLE IF NOT EXISTS inspections(
        id INTEGER PRIMARY KEY AUTOINCREMENT, robot_id TEXT, timestamp TEXT,
        image_url TEXT, result TEXT, confidence REAL, severity TEXT, notes TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS commands(
        id INTEGER PRIMARY KEY AUTOINCREMENT, robot_id TEXT, timestamp TEXT,
        command TEXT, operator TEXT, delivery_status TEXT DEFAULT 'QUEUED')""")
    c.execute("""CREATE TABLE IF NOT EXISTS media(
        id INTEGER PRIMARY KEY AUTOINCREMENT, robot_id TEXT, timestamp TEXT,
        filename TEXT, media_type TEXT, path TEXT, detection_url TEXT, detection_result TEXT,
        detection_confidence REAL, detection_severity TEXT)""")
    # Safe migration for databases created by earlier versions.
    try:
        c.execute("ALTER TABLE telemetry ADD COLUMN ultrasonic_distance REAL")
    except sqlite3.OperationalError:
        pass
    for col, typ in [("detection_url","TEXT"),("detection_result","TEXT"),("detection_confidence","REAL"),("detection_severity","TEXT")]:
        try: c.execute(f"ALTER TABLE media ADD COLUMN {col} {typ}")
        except sqlite3.OperationalError: pass
    c.execute("""CREATE TABLE IF NOT EXISTS ai_conversations(
        id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT, operator TEXT,
        robot_id TEXT, language TEXT, question TEXT, answer TEXT)""")
    # Exact requested login
    user = c.execute("SELECT 1 FROM users WHERE email=?", ("operatorcbe1",)).fetchone()
    if not user:
        c.execute("INSERT INTO users(email,mobile,password_hash,role) VALUES(?,?,?,?)",
                  ("operatorcbe1", "", hp("nethra"), "Operator"))
    # Keep exactly one active robot for this prototype
    c.execute("DELETE FROM robots WHERE id <> 'RG-01'")
    c.execute("INSERT OR IGNORE INTO robots(id,name,station,zone,status) VALUES(?,?,?,?,?)",
              ("RG-01", "RailGuard Scout 01", "Coimbatore", "Zone A", "OFFLINE"))
    c.commit(); c.close()

init()

@app.get("/", response_class=HTMLResponse)
async def index():
    return (BASE / "static/index.html").read_text(encoding="utf-8")

@app.post("/api/login")
async def login(identifier: str = Form(...), password: str = Form(...)):
    c = db(); u = c.execute("SELECT * FROM users WHERE email=?", (identifier.strip(),)).fetchone(); c.close()
    if not u or u["password_hash"] != hp(password):
        return JSONResponse({"ok": False, "message": "Invalid operator ID or password."}, status_code=401)
    token = secrets.token_urlsafe(32); TOKENS[token] = u["email"]
    return {"ok": True, "token": token, "operator": u["email"], "role": u["role"]}

@app.get("/api/fleet")
async def fleet(request: Request):
    if not auth(request): return JSONResponse({"ok": False, "message": "Unauthorized"}, status_code=401)
    c = db(); r = c.execute("SELECT * FROM robots WHERE id='RG-01'").fetchone()
    t = c.execute("SELECT * FROM telemetry WHERE robot_id='RG-01' ORDER BY id DESC LIMIT 1").fetchone()
    c.close()
    if not r: return {"ok": True, "robots": []}
    return {"ok": True, "robots": [{**dict(r), "battery": t["battery_percent"] if t else None,
        "last_communication": t["timestamp"] if t else r["last_seen"]}]}

@app.get("/api/robots/{rid}")
async def robot(rid: str, request: Request):
    if not auth(request): return JSONResponse({"ok": False, "message": "Unauthorized"}, status_code=401)
    c = db(); r = c.execute("SELECT * FROM robots WHERE id=?", (rid,)).fetchone()
    if not r: c.close(); return JSONResponse({"ok": False, "message": "Robot not found"}, status_code=404)
    t = c.execute("SELECT * FROM telemetry WHERE robot_id=? ORDER BY id DESC LIMIT 1", (rid,)).fetchone()
    alerts = c.execute("SELECT * FROM alerts WHERE robot_id=? ORDER BY id DESC LIMIT 10", (rid,)).fetchall()
    insp = c.execute("SELECT * FROM inspections WHERE robot_id=? ORDER BY id DESC LIMIT 1", (rid,)).fetchone()
    media = c.execute("SELECT * FROM media WHERE robot_id=? ORDER BY id DESC LIMIT 12", (rid,)).fetchall()
    c.close(); td = dict(t) if t else {}
    return {"ok": True, **dict(r), "battery": td.get("battery_percent"),
        "battery_voltage": td.get("battery_voltage"), "speed": td.get("speed"),
        "front_distance": td.get("front_distance"), "rear_distance": td.get("rear_distance"),
        "ultrasonic_distance": td.get("ultrasonic_distance"),
        "ultrasonic_status": (
            "NO SENSOR" if td.get("ultrasonic_distance") is None else
            "DANGER" if float(td.get("ultrasonic_distance")) < 20 else
            "WARNING" if float(td.get("ultrasonic_distance")) < 50 else
            "SAFE"
        ),
        "gps": {"lat": td.get("latitude"), "lon": td.get("longitude")},
        "emergency_stop": bool(td.get("emergency_stop")) if t else False,
        "train_approaching": bool(td.get("train_approaching")) if t else False,
        "camera_status": td.get("camera_status", "OFFLINE"),
        "connection_status": td.get("connection_status", "OFFLINE"),
        "defect": {"type": insp["result"] if insp else "NO DATA", "confidence": insp["confidence"] if insp else 0,
                   "severity": insp["severity"] if insp else "UNKNOWN", "image_url": insp["image_url"] if insp else None,
                   "notes": insp["notes"] if insp else ""},
        "alerts": [dict(x) for x in alerts], "media": [dict(x) for x in media],
        "live": bool(t)}

@app.get("/api/telemetry/{rid}")
async def telemetry_latest(rid: str, request: Request):
    if not auth(request): return JSONResponse({"ok": False, "message": "Unauthorized"}, status_code=401)
    c=db(); rows=c.execute("SELECT * FROM telemetry WHERE robot_id=? ORDER BY id DESC LIMIT 100",(rid,)).fetchall(); c.close()
    return {"ok":True,"items":[dict(x) for x in rows]}

@app.get("/api/history/{rid}")
async def history(rid: str, request: Request):
    return await telemetry_latest(rid, request)

@app.get("/api/ultrasonic/{rid}")
async def ultrasonic_latest(rid: str, request: Request):
    if not auth(request):
        return JSONResponse({"ok": False, "message": "Unauthorized"}, status_code=401)
    c = db()
    t = c.execute(
        "SELECT ultrasonic_distance, timestamp FROM telemetry WHERE robot_id=? ORDER BY id DESC LIMIT 1",
        (rid,)
    ).fetchone()
    c.close()
    distance = t["ultrasonic_distance"] if t else None
    status = (
        "NO SENSOR" if distance is None else
        "DANGER" if float(distance) < 20 else
        "WARNING" if float(distance) < 50 else
        "SAFE"
    )
    return {
        "ok": True,
        "distance_cm": distance,
        "status": status,
        "timestamp": t["timestamp"] if t else None
    }

@app.get("/api/alerts")
async def alerts(request: Request):
    if not auth(request): return JSONResponse({"ok": False, "message": "Unauthorized"}, status_code=401)
    c=db(); rows=c.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 100").fetchall(); c.close()
    return {"ok":True,"items":[dict(x) for x in rows]}

@app.post("/api/alerts/{alert_id}/ack")
async def ack_alert(alert_id:int, request:Request):
    if not auth(request): return JSONResponse({"ok":False,"message":"Unauthorized"},status_code=401)
    c=db(); c.execute("UPDATE alerts SET acknowledged=1 WHERE id=?",(alert_id,)); c.commit(); c.close(); return {"ok":True}

@app.get("/api/health-summary")
async def health(request: Request):
    if not auth(request): return JSONResponse({"ok": False, "message": "Unauthorized"}, status_code=401)
    c=db(); t=c.execute("SELECT * FROM telemetry WHERE robot_id='RG-01' ORDER BY id DESC LIMIT 1").fetchone()
    critical=c.execute("SELECT COUNT(*) n FROM alerts WHERE severity='CRITICAL' AND acknowledged=0").fetchone()["n"]
    attention=c.execute("SELECT COUNT(*) n FROM alerts WHERE severity IN ('HIGH','MEDIUM','ATTENTION') AND acknowledged=0").fetchone()["n"]
    c.close(); online=1 if t else 0
    return {"ok":True,"robots_online":online,"robots_total":1,"critical_alerts":critical,"attention_items":attention,
            "overall": round(float(t["battery_percent"]),0) if t and t["battery_percent"] is not None else None}

async def send_esp32(command: str):
    if not ESP32_COMMAND_URL or httpx is None:
        return False, "ESP32_COMMAND_URL not configured"
    try:
        async with httpx.AsyncClient(timeout=4) as client:
            r=await client.post(ESP32_COMMAND_URL, json={"robot_id":"RG-01","command":command,"device_key":DEVICE_KEY})
            return r.is_success, f"HTTP {r.status_code}"
    except Exception as e:
        return False, str(e)

@app.post("/api/robots/{rid}/command")
async def command(rid: str, request: Request):
    operator=auth(request)
    if not operator: return JSONResponse({"ok":False,"message":"Unauthorized"},status_code=401)
    body=await request.json(); cmd=str(body.get("move","")).upper()
    allowed={"FORWARD","BACKWARD","LEFT","RIGHT","STOP","EMERGENCY_STOP"}
    if cmd not in allowed: return JSONResponse({"ok":False,"message":"Invalid command"},status_code=400)
    c=db(); t=c.execute("SELECT * FROM telemetry WHERE robot_id=? ORDER BY id DESC LIMIT 1",(rid,)).fetchone()
    if t and t["emergency_stop"] and cmd not in {"STOP","EMERGENCY_STOP"}:
        c.close(); return JSONResponse({"ok":False,"message":"Emergency stop is active. Clear it on the robot before movement."},status_code=409)
    ok, detail=await send_esp32(cmd)
    status="SENT" if ok else "QUEUED"
    c.execute("INSERT INTO commands(robot_id,timestamp,command,operator,delivery_status) VALUES(?,?,?,?,?)",
              (rid,now(),cmd,operator,status)); c.commit(); c.close()
    return {"ok":True,"command":cmd,"delivery_status":status,"detail":detail}

@app.post("/api/telemetry")
async def telemetry(request: Request):
    if request.headers.get("X-Device-Key") != DEVICE_KEY:
        return JSONResponse({"ok":False,"message":"Invalid device key"},status_code=401)
    data=await request.json(); rid=data.get("robot_id")
    if rid != "RG-01": return JSONResponse({"ok":False,"message":"Unknown robot_id"},status_code=400)
    ts=data.get("timestamp") or now(); train=bool(data.get("train_approaching",False)); estop=bool(data.get("emergency_stop",False))
    ultrasonic = data.get("ultrasonic_distance")
    c=db(); c.execute("""INSERT INTO telemetry(robot_id,timestamp,battery_voltage,battery_percent,latitude,longitude,speed,
        front_distance,rear_distance,ultrasonic_distance,ir_left,ir_right,emergency_stop,train_approaching,camera_status,connection_status)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (rid,ts,data.get("battery_voltage"),data.get("battery_percent"),data.get("latitude"),data.get("longitude"),data.get("speed"),
         data.get("front_distance"),data.get("rear_distance"),ultrasonic,
         int(bool(data.get("ir_left"))) if data.get("ir_left") is not None else None,
         int(bool(data.get("ir_right"))) if data.get("ir_right") is not None else None,
         int(estop),int(train),data.get("camera_status","ONLINE"),"LIVE"))
    c.execute("UPDATE robots SET status='ONLINE',last_seen=? WHERE id=?",(ts,rid))
    if train:
        c.execute("INSERT INTO alerts(robot_id,timestamp,severity,type,message) VALUES(?,?,?,?,?)",
                  (rid,ts,"CRITICAL","TRAIN_APPROACHING","Train approaching. Emergency parking/STOP requested."))
    c.commit(); c.close()
    if train:
        await send_esp32("EMERGENCY_STOP")
    msg=json.dumps({"type":"telemetry","robot_id":rid,"data":data})
    for ws in list(clients):
        try: await ws.send_text(msg)
        except: clients.discard(ws)
    return {"ok":True,"emergency_stop_sent":train}

@app.post("/api/media/upload")
async def media_upload(request: Request, file: UploadFile = File(...), robot_id: str = Form("RG-01")):
    # SD-card sync endpoint. The robot sends images/videos with X-Device-Key.
    if request.headers.get("X-Device-Key") != DEVICE_KEY:
        return JSONResponse({"ok":False,"message":"Invalid device key"},status_code=401)
    ext=Path(file.filename or "capture.bin").suffix.lower()
    allowed={".jpg",".jpeg",".png",".webp",".mp4",".avi",".mov"}
    if ext not in allowed: return JSONResponse({"ok":False,"message":"Unsupported media type"},status_code=400)
    stamp=datetime.now().strftime("%Y%m%d_%H%M%S_%f"); name=f"{robot_id}_{stamp}{ext}"; dest=MEDIA/name
    raw=await file.read(); dest.write_bytes(raw)
    media_type="video" if ext in {".mp4",".avi",".mov"} else "image"
    c=db(); cur=c.execute("INSERT INTO media(robot_id,timestamp,filename,media_type,path) VALUES(?,?,?,?,?)",
                      (robot_id,now(),name,media_type,f"/media/{name}")); media_id=cur.lastrowid; c.commit(); c.close()
    detection = None
    if media_type == "image":
        try:
            best, annotated, objects = yolo_detect_bytes(raw)
            ann_name, ann_url = save_inspection(robot_id, annotated, source="SD")
            result_label, conf, sev, notes = record_yolo_result(robot_id, best, ann_url, "SD card")
            c=db(); c.execute("UPDATE media SET detection_url=?, detection_result=?, detection_confidence=?, detection_severity=? WHERE id=?",
                              (ann_url,result_label,conf,sev,media_id)); c.commit(); c.close()
            detection = {"result":result_label,"confidence":conf,"severity":sev,"annotated_url":ann_url,"notes":notes,"objects":objects}
        except Exception as e:
            detection = {"error":f"SD-card YOLO inspection failed: {type(e).__name__}: {e}"}
    return {"ok":True,"url":f"/media/{name}","media_type":media_type,"detection":detection}

@app.get("/api/media/{rid}")
async def media_list(rid:str, request:Request):
    if not auth(request): return JSONResponse({"ok":False,"message":"Unauthorized"},status_code=401)
    c=db(); rows=c.execute("SELECT * FROM media WHERE robot_id=? ORDER BY id DESC LIMIT 100",(rid,)).fetchall(); c.close()
    return {"ok":True,"items":[dict(x) for x in rows]}

@app.post("/api/live/frame")
async def live_frame(request: Request, file: UploadFile = File(...), robot_id: str = Form("RG-01")):
    # ESP32-CAM/edge computer can POST each JPEG frame here. YOLO runs server-side.
    if not auth(request) and request.headers.get("X-Device-Key") != DEVICE_KEY:
        return JSONResponse({"ok":False,"message":"Unauthorized"},status_code=401)
    try:
        raw = await file.read()
        best, annotated, objects = yolo_detect_bytes(raw)
        image_url = None
        # Save only detection frames, avoiding a huge archive of every live frame.
        if best:
            _, image_url = save_inspection(robot_id, annotated, source="LIVE")
            result_label, conf, sev, notes = record_yolo_result(robot_id, best, image_url, "live camera")
        else:
            result_label, conf, sev, notes = "NO CRACK", 0, "LOW", "YOLOv8 live frame: no crack detected."
        import base64
        return {"ok":True,"result":result_label,"confidence":conf,"severity":sev,"image_url":image_url,
                "annotated_frame":"data:image/jpeg;base64,"+base64.b64encode(annotated).decode(),"notes":notes,"objects":objects}
    except Exception as e:
        return JSONResponse({"ok":False,"message":f"Live YOLO failed: {type(e).__name__}: {e}"},status_code=500)

@app.post("/api/live/pull")
async def live_pull(request: Request, robot_id: str = "RG-01"):
    # Pull one JPEG snapshot from ESP32-CAM's configured capture endpoint and run YOLO.
    if not auth(request): return JSONResponse({"ok":False,"message":"Unauthorized"},status_code=401)
    if not ESP32_CAMERA_URL:
        return JSONResponse({"ok":False,"message":"ESP32_CAMERA_URL is not configured. Connect the ESP32-CAM capture URL first."},status_code=503)
    if httpx is None:
        return JSONResponse({"ok":False,"message":"httpx is not installed."},status_code=500)
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            r = await client.get(ESP32_CAMERA_URL)
            r.raise_for_status()
            raw = r.content
        best, annotated, objects = yolo_detect_bytes(raw)
        image_url = None
        if best:
            _, image_url = save_inspection(robot_id, annotated, source="LIVE")
            result_label, conf, sev, notes = record_yolo_result(robot_id, best, image_url, "live camera")
        else:
            result_label, conf, sev, notes = "NO CRACK", 0, "LOW", "YOLOv8 live frame: no crack detected."
        return {"ok":True,"result":result_label,"confidence":conf,"severity":sev,"image_url":image_url,
                "frame":"data:image/jpeg;base64,"+base64.b64encode(annotated).decode(),"notes":notes,"objects":objects}
    except Exception as e:
        return JSONResponse({"ok":False,"message":f"Could not read ESP32-CAM snapshot: {type(e).__name__}: {e}"},status_code=502)

@app.post("/api/ai/chat")
async def ai_chat(request:Request):
    operator=auth(request)
    if not operator: return JSONResponse({"ok":False,"message":"Unauthorized"},status_code=401)
    body=await request.json(); q=(body.get("message") or "").strip(); rid=body.get("robot_id","RG-01"); lang=body.get("language","en")
    if not q: return JSONResponse({"ok":False,"message":"Message required"},status_code=400)
    c=db(); robot=c.execute("SELECT * FROM robots WHERE id=?",(rid,)).fetchone(); telem=c.execute("SELECT * FROM telemetry WHERE robot_id=? ORDER BY id DESC LIMIT 1",(rid,)).fetchone();
    alerts_rows=c.execute("SELECT * FROM alerts WHERE robot_id=? AND acknowledged=0 ORDER BY id DESC LIMIT 10",(rid,)).fetchall(); insp=c.execute("SELECT * FROM inspections WHERE robot_id=? ORDER BY id DESC LIMIT 5",(rid,)).fetchall(); c.close()
    context={"robot":dict(robot) if robot else None,"latest_telemetry":dict(telem) if telem else None,
             "active_alerts":[dict(x) for x in alerts_rows],"recent_inspections":[dict(x) for x in insp]}
    system=("You are RailGuard AI, a railway inspection dashboard assistant. Use only supplied data for live status; never invent readings. "
            "If unavailable, say DATA UNAVAILABLE. You can explain battery, GPS, telemetry, alerts, inspections, history, SD-card media and robot commands. "
            "Never claim a physical command was executed unless delivery_status is SENT. For emergency train approach, tell the operator to follow railway safety procedures. "
            "Reply in the requested language.")
    prompt=f"{system}\nLanguage:{lang}\nData:{json.dumps(context,default=str)}\nQuestion:{q}"
    if ollama is None: answer="Ollama is not installed."
    else:
        try:
            resp=ollama.chat(model=os.getenv("OLLAMA_MODEL","llama3.2"),messages=[{"role":"system","content":system},{"role":"user","content":prompt}]); answer=resp["message"]["content"]
        except Exception: answer="RailGuard AI is offline. Please start Ollama. Live dashboard data is still available."
    c=db(); c.execute("INSERT INTO ai_conversations(timestamp,operator,robot_id,language,question,answer) VALUES(?,?,?,?,?,?)",(now(),operator,rid,lang,q,answer)); c.commit(); c.close()
    return {"ok":True,"answer":answer}

@app.websocket("/ws")
async def websocket(ws:WebSocket):
    await ws.accept(); clients.add(ws)
    try:
        while True: await ws.receive_text()
    except WebSocketDisconnect: clients.discard(ws)
    except Exception: clients.discard(ws)
