RAILGUARD AI - FINAL DUAL-YOLO DASHBOARD

This build has NO "Test Image" upload section.
The normal inspection flow is camera -> backend -> BOTH YOLO models -> dashboard.

SOFTWARE
- Frontend: HTML5 + CSS3 + JavaScript
- Backend: Python + FastAPI + Uvicorn
- Railway crack AI: Ultralytics YOLO using models/best.pt
- General object AI: Ultralytics YOLO using models/yolov8n.pt
- Database: SQLite
- AI assistant: Ollama + llama3.2
- Maps: Leaflet + OpenStreetMap
- Robot link: ESP32-CAM + HTTP + telemetry
- Ultrasonic safety: separate ESP32 node + HC-SR04 + HTTP telemetry
- Real-time dashboard telemetry: FastAPI WebSocket

1. OPEN THE PROJECT
   cd "RailGuardAI_LIVE_YOLO_OBJECTS_FINAL"

2. CREATE / ACTIVATE VENV
   python -m venv venv
   .\venv\Scripts\Activate.ps1

   If PowerShell says script execution is blocked, run the Python executable
   directly instead of activating:
   .\venv\Scripts\python.exe -m pip install -r requirements.txt

3. INSTALL REQUIREMENTS
   .\venv\Scripts\python.exe -m pip install -r requirements.txt

4. ADD BOTH REAL MODEL FILES
   Put these exact files here:
      models\best.pt
      models\yolov8n.pt

   IMPORTANT WINDOWS PATH NOTE:
   In Python use models/best.pt, not models\best.pt inside a quoted Python
   string. A sequence such as \b becomes a backspace character and causes:
      OSError: [Errno 22] Invalid argument: 'models\\x08est.pt'

5. VERIFY BOTH MODELS
   .\venv\Scripts\python.exe -c "from ultralytics import YOLO; a=YOLO('models/best.pt'); b=YOLO('models/yolov8n.pt'); print('BOTH YOLO MODELS LOADED SUCCESSFULLY'); print('CRACK:', a.names); print('OBJECTS:', list(b.names.items())[:10])"

6. OLLAMA
   Install Ollama separately if it is not installed.
   Start the Ollama service:
      ollama serve

   In another terminal:
      ollama pull llama3.2
      ollama list

   Keep Ollama running while using the RailGuard AI assistant.
   YOLO does NOT require Ollama.

7. OPTIONAL ESP32 SETTINGS
   Copy .env.example to .env and edit:
      YOLO_MODEL=models/best.pt
      OBJECT_YOLO_MODEL=models/yolov8n.pt
      ESP32_COMMAND_URL=http://YOUR_ESP32_OR_SERVER/command
      ESP32_CAMERA_URL=http://YOUR_ESP32_OR_SERVER/capture
      DEVICE_KEY=railguard-device-01
      OLLAMA_MODEL=llama3.2

   The ESP32 must be able to reach the PC running FastAPI over the same
   network. Replace the PC/ESP32 addresses with your real local IPs.

8. START THE DASHBOARD
   .\venv\Scripts\python.exe -m uvicorn app.main:app --host 0.0.0.0 --port 8000

   Open:
      http://127.0.0.1:8000

9. LOGIN
   Operator ID: operatorcbe1
   Password: nethra

10. AI INSPECTION
    Dashboard -> AI Inspection -> Connect Robot Camera.

    Each camera frame is processed by:
      best.pt     -> railway crack detection
      yolov8n.pt  -> general object detection

    The dashboard shows both result groups from the same frame.

11. LAPTOP CAMERA
    The Laptop Camera button is only a live-camera development option.
    It is NOT a file-upload test-image feature. It sends browser camera frames
    to the same backend endpoint and runs both YOLO models.

12. ESP32 FIRMWARE
    See firmware/RailGuard_ESP32_Firmware.ino.
    Set WIFI_SSID, WIFI_PASSWORD, BACKEND_URL and DEVICE_KEY before flashing.

13. QUICK CHECK IF DASHBOARD LOOKS OLD
    Stop every old uvicorn/python process.
    Start this exact project folder again with the command in step 8.
    Then hard-refresh Chrome with Ctrl+F5.
    Make sure the terminal's current directory is this project's folder.

IMPORTANT
This is a prototype research/hackathon system. It is not safety-certified
railway inspection equipment and should not be deployed on live railway
infrastructure without appropriate engineering, validation and certification.


14. ULTRASONIC SENSOR
    This final build includes a real ultrasonic telemetry path.

    Hardware:
      - ESP32 DevKit (separate small node)
      - HC-SR04 or compatible ultrasonic sensor
      - 5V-to-3.3V level shifting/divider for ECHO

    Firmware:
      firmware/RailGuard_Ultrasonic_Node.ino

    Set these values in that file:
      WIFI_SSID
      WIFI_PASSWORD
      BACKEND_URL
      DEVICE_KEY

    The ultrasonic node posts:
      {"robot_id":"RG-01","ultrasonic_distance":24.6}

    FastAPI stores it in SQLite, broadcasts it over the existing /ws
    WebSocket, and the dashboard updates the Ultrasonic Safety card.

    Safety thresholds used by the dashboard:
      >= 50 cm  -> SAFE
      20-49.9cm -> WARNING
      < 20 cm   -> DANGER

    These thresholds are prototype UI rules and must be calibrated for
    the actual robot.

15. IMPORTANT ESP32-CAM GPIO NOTE
    Do NOT blindly connect an HC-SR04 to the AI Thinker ESP32-CAM GPIOs in
    this build. Camera + SD_MMC + GPS + motor control already consume most
    usable pins. The supplied separate ultrasonic node avoids those conflicts.

16. REAL-TIME TELEMETRY
    The project already had FastAPI WebSocket support at /ws. This build
    extends the existing telemetry broadcast with ultrasonic_distance.
    The browser dashboard receives the value immediately over the same
    persistent WebSocket connection instead of polling a second endpoint.

17. RUNNING WITH BOTH HARDWARE NODES
    - Start FastAPI on the PC.
    - Connect the ESP32-CAM and verify its /capture URL.
    - Connect the ultrasonic ESP32 to the same Wi-Fi.
    - Flash both firmware files with the same DEVICE_KEY and robot ID.
    - Open the dashboard and sign in.
    - Open Dashboard or Telemetry. The Ultrasonic Safety card will update
      whenever telemetry arrives.
