/*
  RailGuard AI - ESP32-CAM Firmware
  Target: AI Thinker ESP32-CAM + GPS + L298N/TB6612 motor driver + microSD

  Matches the uploaded RailGuard backend:
    GET  /capture
    POST /command
    POST /api/telemetry
    POST /api/media/upload

  IMPORTANT:
  - Set WIFI_SSID, WIFI_PASSWORD and BACKEND_URL.
  - BACKEND_URL must be reachable from the ESP32, e.g. http://192.168.1.50:8000
  - This is a prototype inspection robot firmware. Do NOT use it on live railway
    infrastructure or as a safety-certified train-detection/parking system.
  - For an AI Thinker ESP32-CAM, GPIO availability is constrained by the camera.
    This example uses:
      GPS RX/TX: GPIO13 / GPIO12
      Motor A: GPIO1 / GPIO3
      Motor B: GPIO4 / GPIO16
    These pins may conflict with your particular carrier/programming setup.
    Verify your exact board and motor-driver wiring before powering motors.
*/

#include <WiFi.h>
#include <WebServer.h>
#include <HTTPClient.h>
#include <WiFiClient.h>
#include "esp_camera.h"
#include "FS.h"
#include "SD_MMC.h"
#include <TinyGPSPlus.h>
#include <time.h>

// ---------------- USER CONFIG ----------------
const char* WIFI_SSID     = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// Laptop/PC running RailGuard FastAPI:
const char* BACKEND_URL = "http://192.168.1.100:8000";

// Must match RailGuard .env:
// DEVICE_KEY=railguard-device-01
const char* DEVICE_KEY = "railguard-device-01";

const char* ROBOT_ID = "RG-01";

// Telemetry interval
const unsigned long TELEMETRY_MS = 2000;

// Upload SD-card image every N milliseconds when Wi-Fi is available
const unsigned long SD_SYNC_MS = 15000;

// ---------------- ESP32-CAM AI THINKER ----------------
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27

#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

// ---------------- GPS ----------------
// Example: GPS TX -> ESP32 GPIO13 (RX)
//         GPS RX -> ESP32 GPIO12 (TX), if required
HardwareSerial GPSSerial(1);
TinyGPSPlus gps;

// ---------------- MOTOR DRIVER ----------------
// These are example control pins only.
// Adapt them to your actual driver and board.
const int MOTOR_A_IN1 = 1;
const int MOTOR_A_IN2 = 3;
const int MOTOR_B_IN1 = 4;
const int MOTOR_B_IN2 = 16;

WebServer server(80);

unsigned long lastTelemetry = 0;
unsigned long lastSDSync = 0;
bool emergencyStop = false;
String lastCommand = "STOP";

// ---------------- HELPERS ----------------
String isoTimestamp() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo, 100)) {
    return "";
  }

  char buf[32];
  strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", &timeinfo);
  return String(buf);
}

void stopMotors() {
  digitalWrite(MOTOR_A_IN1, LOW);
  digitalWrite(MOTOR_A_IN2, LOW);
  digitalWrite(MOTOR_B_IN1, LOW);
  digitalWrite(MOTOR_B_IN2, LOW);
  lastCommand = "STOP";
}

void forwardMotors() {
  if (emergencyStop) return;
  digitalWrite(MOTOR_A_IN1, HIGH);
  digitalWrite(MOTOR_A_IN2, LOW);
  digitalWrite(MOTOR_B_IN1, HIGH);
  digitalWrite(MOTOR_B_IN2, LOW);
  lastCommand = "FORWARD";
}

void backwardMotors() {
  if (emergencyStop) return;
  digitalWrite(MOTOR_A_IN1, LOW);
  digitalWrite(MOTOR_A_IN2, HIGH);
  digitalWrite(MOTOR_B_IN1, LOW);
  digitalWrite(MOTOR_B_IN2, HIGH);
  lastCommand = "BACKWARD";
}

void leftMotors() {
  if (emergencyStop) return;
  digitalWrite(MOTOR_A_IN1, LOW);
  digitalWrite(MOTOR_A_IN2, HIGH);
  digitalWrite(MOTOR_B_IN1, HIGH);
  digitalWrite(MOTOR_B_IN2, LOW);
  lastCommand = "LEFT";
}

void rightMotors() {
  if (emergencyStop) return;
  digitalWrite(MOTOR_A_IN1, HIGH);
  digitalWrite(MOTOR_A_IN2, LOW);
  digitalWrite(MOTOR_B_IN1, LOW);
  digitalWrite(MOTOR_B_IN2, HIGH);
  lastCommand = "RIGHT";
}

// ---------------- CAMERA ----------------
bool initCamera() {
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sscb_sda = SIOD_GPIO_NUM;
  config.pin_sscb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;

  if (psramFound()) {
    config.frame_size = FRAMESIZE_VGA;
    config.jpeg_quality = 10;
    config.fb_count = 2;
  } else {
    config.frame_size = FRAMESIZE_QVGA;
    config.jpeg_quality = 12;
    config.fb_count = 1;
  }

  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed: 0x%x\n", err);
    return false;
  }

  sensor_t* s = esp_camera_sensor_get();
  if (s) {
    s->set_brightness(s, 0);
    s->set_contrast(s, 0);
    s->set_saturation(s, 0);
  }
  return true;
}

// ---------------- SD CARD ----------------
// 1-bit SD mode leaves more GPIO available than 4-bit mode.
bool initSD() {
  if (!SD_MMC.begin("/sdcard", true)) {
    Serial.println("SD_MMC mount failed");
    return false;
  }

  uint8_t cardType = SD_MMC.cardType();
  if (cardType == CARD_NONE) {
    Serial.println("No SD card");
    return false;
  }

  Serial.printf("SD card size: %llu MB\n",
                SD_MMC.cardSize() / (1024ULL * 1024ULL));
  return true;
}

// ---------------- WEB ENDPOINTS ----------------
bool validDeviceKey() {
  if (!server.hasHeader("X-Device-Key")) return false;
  return server.header("X-Device-Key") == DEVICE_KEY;
}

void handleCapture() {
  camera_fb_t* fb = esp_camera_fb_get();
  if (!fb) {
    server.send(503, "text/plain", "Camera capture failed");
    return;
  }

  WiFiClient client = server.client();
  server.sendHeader("Cache-Control", "no-store");
  server.setContentLength(fb->len);
  server.send(200, "image/jpeg", "");
  client.write(fb->buf, fb->len);

  esp_camera_fb_return(fb);
}

void handleCommand() {
  if (!validDeviceKey()) {
    server.send(401, "application/json",
                "{\"ok\":false,\"message\":\"Invalid device key\"}");
    return;
  }

  String body = server.arg("plain");
  Serial.println("Command: " + body);

  if (body.indexOf("\"command\":\"EMERGENCY_STOP\"") >= 0 ||
      body.indexOf("\"command\":\"STOP\"") >= 0) {
    emergencyStop = body.indexOf("\"command\":\"EMERGENCY_STOP\"") >= 0;
    stopMotors();
  } else if (body.indexOf("\"command\":\"FORWARD\"") >= 0) {
    forwardMotors();
  } else if (body.indexOf("\"command\":\"BACKWARD\"") >= 0) {
    backwardMotors();
  } else if (body.indexOf("\"command\":\"LEFT\"") >= 0) {
    leftMotors();
  } else if (body.indexOf("\"command\":\"RIGHT\"") >= 0) {
    rightMotors();
  } else {
    server.send(400, "application/json",
                "{\"ok\":false,\"message\":\"Unknown command\"}");
    return;
  }

  String response = String("{\"ok\":true,\"command\":\"") +
                    lastCommand + "\",\"emergency_stop\":" +
                    (emergencyStop ? "true" : "false") + "}";
  server.send(200, "application/json", response);
}

// ---------------- TELEMETRY ----------------
void readGPS() {
  while (GPSSerial.available()) {
    gps.encode(GPSSerial.read());
  }
}

String gpsJson() {
  if (gps.location.isValid()) {
    return String(gps.location.lat(), 6) + "," +
           String(gps.location.lng(), 6);
  }
  return "null,null";
}

void sendTelemetry() {
  if (WiFi.status() != WL_CONNECTED) return;

  readGPS();

  String lat = gps.location.isValid() ? String(gps.location.lat(), 6) : "null";
  String lon = gps.location.isValid() ? String(gps.location.lng(), 6) : "null";
  String speed = gps.speed.isValid() ? String(gps.speed.kmph(), 2) : "null";

  // Replace these prototype values with readings from your actual battery/
  // distance/IR hardware when connected.
  float batteryVoltage = 0.0;
  float batteryPercent = 0.0;

  String json = "{";
  json += "\"robot_id\":\"" + String(ROBOT_ID) + "\",";
  json += "\"timestamp\":\"" + isoTimestamp() + "\",";
  json += "\"battery_voltage\":" + String(batteryVoltage, 2) + ",";
  json += "\"battery_percent\":" + String(batteryPercent, 1) + ",";
  json += "\"latitude\":" + lat + ",";
  json += "\"longitude\":" + lon + ",";
  json += "\"speed\":" + speed + ",";
  json += "\"front_distance\":null,";
  json += "\"rear_distance\":null,";
  json += "\"ir_left\":null,";
  json += "\"ir_right\":null,";
  json += "\"emergency_stop\":" + String(emergencyStop ? "true" : "false") + ",";
  json += "\"train_approaching\":false,";
  json += "\"camera_status\":\"ONLINE\",";
  json += "\"connection_status\":\"LIVE\"";
  json += "}";

  HTTPClient http;
  String url = String(BACKEND_URL) + "/api/telemetry";

  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Key", DEVICE_KEY);

  int code = http.POST(json);
  Serial.printf("Telemetry HTTP: %d\n", code);
  http.end();
}

// ---------------- SD SYNC ----------------
// Sends the first JPG/JPEG/PNG found in /captures.
// After successful upload, moves it to /uploaded.
bool uploadOneSDImage() {
  if (WiFi.status() != WL_CONNECTED) return false;

  File root = SD_MMC.open("/captures");
  if (!root || !root.isDirectory()) {
    return false;
  }

  File file = root.openNextFile();
  while (file) {
    String path = file.name();
    bool isImage = path.endsWith(".jpg") || path.endsWith(".JPG") ||
                   path.endsWith(".jpeg") || path.endsWith(".JPEG") ||
                   path.endsWith(".png") || path.endsWith(".PNG");

    if (isImage) {
      size_t len = file.size();
      uint8_t* data = (uint8_t*)malloc(len);

      if (!data) {
        file.close();
        root.close();
        Serial.println("Not enough RAM for SD image");
        return false;
      }

      file.read(data, len);
      file.close();
      root.close();

      // Multipart upload
      String boundary = "----RailGuardBoundary";
      String header = "--" + boundary + "\r\n";
      header += "Content-Disposition: form-data; name=\"file\"; filename=\"" +
                path.substring(path.lastIndexOf('/') + 1) + "\"\r\n";
      header += "Content-Type: image/jpeg\r\n\r\n";
      String footer = "\r\n--" + boundary + "--\r\n";

      HTTPClient http;
      String url = String(BACKEND_URL) + "/api/media/upload";

      WiFiClient client;
      if (!http.begin(client, url)) {
        free(data);
        return false;
      }

      http.addHeader("Content-Type", "multipart/form-data; boundary=" + boundary);
      http.addHeader("X-Device-Key", DEVICE_KEY);

      // Build a single buffer only for modest prototype images.
      size_t total = header.length() + len + footer.length();
      uint8_t* packet = (uint8_t*)malloc(total);

      if (!packet) {
        free(data);
        http.end();
        Serial.println("Not enough RAM for multipart packet");
        return false;
      }

      size_t pos = 0;
      memcpy(packet + pos, header.c_str(), header.length());
      pos += header.length();
      memcpy(packet + pos, data, len);
      pos += len;
      memcpy(packet + pos, footer.c_str(), footer.length());

      int code = http.POST(packet, total);
      Serial.printf("SD upload %s -> HTTP %d\n", path.c_str(), code);

      free(packet);
      free(data);
      http.end();

      if (code >= 200 && code < 300) {
        String uploadedDir = "/uploaded";
        if (!SD_MMC.exists(uploadedDir)) SD_MMC.mkdir(uploadedDir);

        String dest = uploadedDir + "/" +
                      path.substring(path.lastIndexOf('/') + 1);
        SD_MMC.rename(path, dest);
        return true;
      }
      return false;
    }

    file.close();
    file = root.openNextFile();
  }

  root.close();
  return false;
}

// ---------------- SETUP ----------------
void setup() {
  Serial.begin(115200);
  delay(1000);

  pinMode(MOTOR_A_IN1, OUTPUT);
  pinMode(MOTOR_A_IN2, OUTPUT);
  pinMode(MOTOR_B_IN1, OUTPUT);
  pinMode(MOTOR_B_IN2, OUTPUT);
  stopMotors();

  // GPS UART.
  // GPS TX -> GPIO13, GPS RX -> GPIO12.
  GPSSerial.begin(9600, SERIAL_8N1, 13, 12);

  if (!initCamera()) {
    Serial.println("WARNING: camera unavailable");
  }

  if (!initSD()) {
    Serial.println("WARNING: SD unavailable");
  } else {
    if (!SD_MMC.exists("/captures")) SD_MMC.mkdir("/captures");
    if (!SD_MMC.exists("/uploaded")) SD_MMC.mkdir("/uploaded");
  }

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  Serial.print("Connecting to Wi-Fi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.print("ESP32 IP: ");
  Serial.println(WiFi.localIP());

  configTime(0, 0, "pool.ntp.org", "time.nist.gov");

  // HTTP endpoints expected by the RailGuard backend.
  server.on("/capture", HTTP_GET, handleCapture);
  server.on("/command", HTTP_POST, handleCommand);

  server.begin();
  Serial.println("RailGuard ESP32 server started");
  Serial.println("Camera URL should be:");
  Serial.print("http://");
  Serial.print(WiFi.localIP());
  Serial.println("/capture");

  Serial.println("Command URL should be:");
  Serial.print("http://");
  Serial.print(WiFi.localIP());
  Serial.println("/command");
}

// ---------------- LOOP ----------------
void loop() {
  server.handleClient();
  readGPS();

  unsigned long nowMs = millis();

  if (nowMs - lastTelemetry >= TELEMETRY_MS) {
    lastTelemetry = nowMs;
    sendTelemetry();
  }

  if (nowMs - lastSDSync >= SD_SYNC_MS) {
    lastSDSync = nowMs;
    uploadOneSDImage();
  }

  delay(5);
}
