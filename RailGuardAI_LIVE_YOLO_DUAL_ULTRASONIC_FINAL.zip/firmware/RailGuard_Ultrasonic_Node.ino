/*
  RailGuard AI - Ultrasonic Telemetry Node
  Target: ESP32 DevKit + HC-SR04 (or compatible ultrasonic sensor)

  Why a separate node?
  The AI Thinker ESP32-CAM in this project already uses many GPIOs for
  camera + microSD + GPS + motor control. A separate small ESP32 avoids
  pin conflicts and gives the ultrasonic sensor a clean connection.

  Wiring example:
    HC-SR04 VCC  -> 5V
    HC-SR04 GND  -> GND
    HC-SR04 TRIG -> GPIO 5
    HC-SR04 ECHO -> GPIO 18 THROUGH A 5V-to-3.3V LEVEL SHIFTER / DIVIDER

  The node sends:
    POST http://YOUR_PC_IP:8000/api/telemetry

  It uses the same robot_id and device key as RailGuard.
*/

#include <WiFi.h>
#include <HTTPClient.h>
#include <time.h>

const char* WIFI_SSID     = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* BACKEND_URL   = "http://192.168.1.100:8000";
const char* DEVICE_KEY    = "railguard-device-01";
const char* ROBOT_ID      = "RG-01";

#define ULTRASONIC_TRIG_PIN 5
#define ULTRASONIC_ECHO_PIN 18

const unsigned long TELEMETRY_MS = 1000;
unsigned long lastTelemetry = 0;

float readUltrasonicCM() {
  digitalWrite(ULTRASONIC_TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(ULTRASONIC_TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(ULTRASONIC_TRIG_PIN, LOW);

  long duration = pulseIn(ULTRASONIC_ECHO_PIN, HIGH, 30000);
  if (duration == 0) return -1.0;

  return (duration * 0.0343f) / 2.0f;
}

void sendUltrasonicTelemetry() {
  if (WiFi.status() != WL_CONNECTED) return;

  float distance = readUltrasonicCM();

  String json = "{";
  json += "\"robot_id\":\"" + String(ROBOT_ID) + "\",";
  json += "\"timestamp\":\"\",";
  json += "\"ultrasonic_distance\":";
  if (distance < 0) json += "null";
  else json += String(distance, 2);
  json += "}";

  HTTPClient http;
  String url = String(BACKEND_URL) + "/api/telemetry";
  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Key", DEVICE_KEY);

  int code = http.POST(json);
  Serial.printf("Ultrasonic %.1f cm -> HTTP %d\n", distance, code);
  http.end();
}

void setup() {
  Serial.begin(115200);
  pinMode(ULTRASONIC_TRIG_PIN, OUTPUT);
  pinMode(ULTRASONIC_ECHO_PIN, INPUT);
  digitalWrite(ULTRASONIC_TRIG_PIN, LOW);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  Serial.print("Connecting to Wi-Fi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.print("Ultrasonic node IP: ");
  Serial.println(WiFi.localIP());
}

void loop() {
  unsigned long nowMs = millis();

  if (nowMs - lastTelemetry >= TELEMETRY_MS) {
    lastTelemetry = nowMs;
    sendUltrasonicTelemetry();
  }

  delay(5);
}
