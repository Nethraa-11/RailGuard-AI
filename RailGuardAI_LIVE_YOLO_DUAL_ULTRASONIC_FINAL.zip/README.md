# RailGuard AI Real Dashboard - FIXED

This build fixes the 401 -> undefined.map problem.

## Why the previous version failed
The browser was calling `/api/fleet` without sending the login token. The API correctly returned 401 Unauthorized, then the frontend tried to run `.map()` on a missing `robots` array.

## What is fixed
- Login token is stored in localStorage and also in an HttpOnly cookie.
- Every authenticated frontend API call uses `Authorization: Bearer <token>`.
- The server accepts either the Bearer token or the session cookie.
- Expired sessions automatically return to the login page.
- Fleet rendering safely handles missing/invalid API data.
- No fabricated sensor readings are displayed.
- Hardware state is explicitly shown as WAITING FOR HARDWARE.
- English, Tamil and Hindi UI are included.
- `/api/telemetry` is ready for later ESP32 integration, but production device authentication must be added before field deployment.

## Run
Windows PowerShell:

py -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

Open http://127.0.0.1:8000

Demo login:
operator@railguard.local
RailGuard@123

These credentials are for the prototype only.
